var express=require('express');
var exe=require('./connection');
var route=express.Router();
route.get("/",async function(req,res){
    var data=await exe("SELECT * FROM basic_info");
    var about_us=await exe("SELECT * FROM about_us");
    var shop_info=await exe("SELECT * FROM shop_info");
    res.render('user/home.ejs',{"info":data[0],"about_us":about_us[0],"shop_info":shop_info});
});
route.get("/features",function(req,res){
    res.render('user/features.ejs');
});
route.get("/shop",async function(req,res){
    var shop_info=await exe("SELECT * FROM shop_info");
    res.render('user/shop.ejs',{"shop_info":shop_info});
});
route.get("/shop_details",function(req,res){
    res.render('user/shop_details.ejs');
});
route.get("/cart",function(req,res){
    res.render('user/cart.ejs');
});
route.get("/checkout",function(req,res){
    res.render('user/checkout.ejs');
});
route.get("/testimonial",function(req,res){
    res.render('user/testimonial.ejs');
});
route.get("/contact",function(req,res){
    res.render('user/contact.ejs');
});
module.exports=route;