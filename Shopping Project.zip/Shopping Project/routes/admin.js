var express=require('express');
var exe=require('./connection');
var route=express.Router();
route.get("/",function(req,res){
    res.render('admin/home.ejs');
});
route.get("/basic_information",async function(req,res)
{
    var data=await exe("SELECT * FROM basic_info");
    res.render("admin/basic_info.ejs",{"info":data[0]});
});
route.post("/save_basic_info",async function(req,res){
    var d=req.body;
    //var sql=`INSERT INTO basic_info(mobile,mail,address) VALUES ('${d.mobile_no}','${d.email_id}','${d.address}')`;
   var sql=`UPDATE basic_info SET mobile='${d.mobile_no}',mail='${d.email_id}',address='${d.address}'`;
   await exe(sql);
   res.redirect("/admin/basic_information");
});
route.get("/about_us",async function(req,res){
    var data=await exe("SELECT * FROM about_us");
    res.render('admin/about_us.ejs',{"about_info":data[0]});
});
route.post("/save_about_info",async function(req,res){
    var d=req.body;
    var sql=`UPDATE about_us SET heading="${d.heading}",sub_heading="${d.sub_heading}",key_point1="${d.key_point1}",feature1="${d.feature1}",key_point2="${d.key_point2}",feature2="${d.feature2}",key_point3="${d.key_point3}",feature3="${d.feature3}",key_point4="${d.key_point4}",feature4="${d.feature4}"`;
    var data=await exe(sql);
   // var data= await exe("INSERT INTO about_us(heading) VALUES ('')");
    res.redirect("/admin/about_us")
});
route.get("/shop",async function(req,res){
    var data=await exe("SELECT * FROM shop_info");
    res.render("admin/shop.ejs",{"info":data});
});
route.post("/save_shop_info",async function(req,res)
{
  var fruits_image= new Date().getTime()+req.files.fruits_image.name;
  req.files.fruits_image.mv("public/img/"+fruits_image);
  var d=req.body;
  var sql=`INSERT INTO shop_info(grossary_name,fruits_image,fruits_name,fruits_desc,fruits_price) VALUES ('${d.grossary_name}','${fruits_image}','${d.fruits_name}','${d.fruits_desc}','${d.fruits_price}')`;
  var data=await exe(sql);
  res.redirect("/admin/shop");
});
route.get("/features",function(req,res){
    res.render("admin/features.ejs");
});
route.post("/save_features",async function(req,res){
    var grossary_image= new Date().getTime()+req.files.image.name;
  req.files.image.mv("public/img/"+grossary_image);
  var d=req.body;
  var sql=`INSERT INTO features(image,feature,offer) VALUES ('${image}','${d.features}','${d.offers}')`;
  var data=await exe(sql);
  res.redirect("/admin/features");
   
});
module.exports=route;