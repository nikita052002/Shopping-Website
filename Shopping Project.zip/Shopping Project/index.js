var express= require('express');
var util=require('util');
var userRoute=require("./routes/user")
var adminRoute=require("./routes/admin")
var bodyparser=require('body-parser');
var upload=require('express-fileupload');
var session=require('express-session');
var app=express();
app.use(bodyparser.urlencoded({extended:true}));
app.use(upload());
app.use(session({
    secret:"Nikita",
    resave:true,
    saveUninitialized:true
}));
app.use("/",userRoute);
app.use("/admin",adminRoute);
app.use(express.static("public/"));
app.listen(1000);
